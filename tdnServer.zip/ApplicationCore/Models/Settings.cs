﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationCore.Models
{
    public class Settings
    {
        public string Domain { get; set; }
    }
}
