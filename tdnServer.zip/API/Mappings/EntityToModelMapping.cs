﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models.Computer;

namespace WebAPI.Mappings
{
    public class EntityToModelMapping : Profile
    {
        public EntityToModelMapping()
        {

        }
    }
}
