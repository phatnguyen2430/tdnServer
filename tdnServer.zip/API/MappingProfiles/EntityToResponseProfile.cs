﻿using AutoMapper;
using WebAPI.Models.Computer;
namespace WebAPI.MappingProfiles
{
    public class EntityToResponseProfile : Profile
    {
        public EntityToResponseProfile()
        {

        }
    }
}
