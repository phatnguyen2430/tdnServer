﻿using ApplicationCore.Interfaces;
using Hangfire;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.Services
{
    public class HangfireService : IHangfireService
    {
        public void Start()
        {
            throw new NotImplementedException();
        }
    }
}
